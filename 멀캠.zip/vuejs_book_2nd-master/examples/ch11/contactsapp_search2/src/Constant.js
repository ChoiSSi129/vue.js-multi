export default {
    ADD_KEYWORD : 'addKeyword',
    SEARCH_CONTACT : "searchContact",
    BASE_URL : "http://sample.bmaster.kro.kr/contacts_long/search/"
}