export let var1 = 1000;
export function add(a,b) {
    return a+b;
}
