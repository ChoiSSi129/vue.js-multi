import { add, var1 as v  } from './utils/utility1';

console.log(add(4,5));
console.log(v);
