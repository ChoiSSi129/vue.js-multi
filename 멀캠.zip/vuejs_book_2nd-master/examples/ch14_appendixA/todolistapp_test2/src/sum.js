const sum = function(a,b) {
    return a+b;
}
export default sum;