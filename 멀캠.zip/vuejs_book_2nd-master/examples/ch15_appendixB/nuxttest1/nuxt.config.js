module.exports = {
  head: {
    link: [
      { 
        rel: 'stylesheet', 
        href: 'https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css' 
      }
    ]
  }
}